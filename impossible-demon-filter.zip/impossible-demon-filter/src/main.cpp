#include <Geode/Geode.hpp>
#include <Geode/modify/DemonFilterSelectLayer.hpp>
#include <Geode/utils/web.hpp>

#include <algorithm>
#include <ctime>
#include <string>
#include <utility>
#include <vector>

using namespace geode::prelude;

namespace {
	// Community "hardest demons" ranking (AREDL). Each entry has a GD level id and a rank.
	constexpr char const* LIST_URL = "https://api.aredl.net/v2/api/aredl/levels";

	TaskHolder<web::WebResponse> g_request;

	// ids sorted hardest (#1) first
	std::vector<int> cachedIDs() {
		return Mod::get()->getSavedValue<std::vector<int>>("ids", {});
	}

	bool cacheFresh() {
		auto ids = cachedIDs();
		if (ids.empty()) return false;
		auto hours = Mod::get()->getSettingValue<int64_t>("cache-hours");
		auto fetched = Mod::get()->getSavedValue<int64_t>("fetched-at", 0);
		return std::time(nullptr) - fetched < hours * 3600;
	}

	void openBrowser(std::vector<int> ids) {
		auto size = static_cast<size_t>(Mod::get()->getSettingValue<int64_t>("list-size"));
		if (ids.size() > size) ids.resize(size);
		if (ids.empty()) {
			Notification::create("Impossible list is empty", NotificationIcon::Error)->show();
			return;
		}
		// default order is top N -> top 1
		if (!Mod::get()->getSettingValue<bool>("hardest-first")) {
			std::reverse(ids.begin(), ids.end());
		}

		std::string joined;
		for (size_t i = 0; i < ids.size(); i++) {
			if (i) joined += ",";
			joined += std::to_string(ids[i]);
		}

		// Same search type GD uses when you open a map pack: a comma-separated list of level ids.
		auto search = GJSearchObject::create(SearchType::MapPackOnClick, joined);
		auto scene = LevelBrowserLayer::scene(search);
		CCDirector::get()->replaceScene(CCTransitionFade::create(0.5f, scene));
	}

	void loadAndOpen() {
		if (cacheFresh()) {
			openBrowser(cachedIDs());
			return;
		}

		Notification::create("Loading Impossible Demon list...", NotificationIcon::Loading, 1.5f)->show();

		g_request.spawn(web::WebRequest().get(LIST_URL), [](web::WebResponse res) {
			std::vector<std::pair<int, int>> ranked; // (rank, level id)

			if (res.ok()) {
				if (auto json = res.json()) {
					auto value = json.unwrap();
					if (auto arr = value.asArray()) {
						int fallbackRank = 0;
						for (auto& entry : arr.unwrap()) {
							fallbackRank++;
							int id = static_cast<int>(entry["level_id"].asInt().unwrapOr(0));
							int rank = static_cast<int>(entry["position"].asInt().unwrapOr(fallbackRank));
							if (id > 0) ranked.push_back({rank, id});
						}
					}
				}
			}

			if (ranked.empty()) {
				// Network/parse failure: fall back to whatever we downloaded before.
				if (!cachedIDs().empty()) {
					Notification::create("Couldn't refresh list, using saved copy", NotificationIcon::Warning)->show();
					openBrowser(cachedIDs());
				} else {
					Notification::create("Couldn't load the Impossible Demon list", NotificationIcon::Error)->show();
				}
				return;
			}

			std::sort(ranked.begin(), ranked.end());
			std::vector<int> ids;
			ids.reserve(ranked.size());
			for (auto& [rank, id] : ranked) ids.push_back(id);

			Mod::get()->setSavedValue<std::vector<int>>("ids", ids);
			Mod::get()->setSavedValue<int64_t>("fetched-at", static_cast<int64_t>(std::time(nullptr)));
			openBrowser(std::move(ids));
		});
	}
}

class $modify(ImpossibleDemonFilter, DemonFilterSelectLayer) {
	bool init() {
		if (!DemonFilterSelectLayer::init()) return false;

		// Place the new button just under the lowest existing button in the popup.
		float lowest = 0.f;
		bool any = false;
		if (auto children = m_buttonMenu->getChildren()) {
			for (auto child : CCArrayExt<CCNode*>(children)) {
				float bottom = child->getPositionY() - child->getContentSize().height * child->getScaleY() / 2.f;
				if (!any || bottom < lowest) lowest = bottom;
				any = true;
			}
		}
		if (!any) lowest = -60.f;

		auto face = CCSprite::create(Mod::get()->expandSpriteName("impossible.png"));
		if (!face) return true;
		face->setScale(34.f / face->getContentSize().width);

		auto label = CCLabelBMFont::create("Impossible", "bigFont.fnt");
		label->setPosition({face->getContentSize().width / 2.f, -10.f / face->getScale()});
		label->setScale(0.35f / face->getScale());
		face->addChild(label);

		auto btn = CCMenuItemSpriteExtra::create(face, this, menu_selector(ImpossibleDemonFilter::onImpossible));
		btn->setID("impossible-demon-button"_spr);
		btn->setPosition({
			static_cast<float>(Mod::get()->getSettingValue<int64_t>("button-offset-x")),
			lowest - 34.f + static_cast<float>(Mod::get()->getSettingValue<int64_t>("button-offset-y"))
		});
		m_buttonMenu->addChild(btn);
		return true;
	}

	void onImpossible(CCObject*) {
		this->keyBackClicked(); // close the popup
		loadAndOpen();
	}
};
