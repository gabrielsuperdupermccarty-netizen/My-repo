# Impossible Demon Filter

Adds an **Impossible Demon** button to the demon filter popup. Pressing it opens a level browser with the hardest demons (default top 500, shown from #500 down to #1).

The ranking is downloaded from the AREDL list and cached; size, order and refresh time are in the mod settings.
